package com.example.model

data class Server(
    val id: String,
    val name: String,
    val quality: String,
    val isRecommended: Boolean = false,
    val status: String = "ممتاز"
)

data class Movie(
    val id: String,
    val titleAr: String,
    val titleEn: String,
    val description: String,
    val rating: Double,
    val year: String,
    val duration: String,
    val category: String, // "arabic" or "foreign"
    val genre: String,
    val backdropUrl: String,
    val posterUrl: String,
    val servers: List<Server>,
    val cast: List<String> = listOf("طارق لطفى", "أحمد السقا", "منة شلبي"),
    val reviewsCount: Int = 1245
)

data class Team(
    val nameAr: String,
    val logoUrl: String,
    val score: Int
)

data class Match(
    val id: String,
    val title: String,
    val league: String,
    val teamA: Team,
    val teamB: Team,
    val liveMinute: String,
    val status: String, // "LIVE", "UPCOMING", "FINISHED"
    val time: String,
    val servers: List<Server>,
    val channel: String,
    val commentator: String
)

data class TVChannel(
    val id: String,
    val nameAr: String,
    val nameEn: String,
    val logoText: String,
    val currentShow: String,
    val iconColor: Long, // Hex representation
    val category: String, // "رياضة", "ترفيه", "أخبار", "أطفال"
    val servers: List<Server>
)

object MockDataProvider {
    val serversList = listOf(
        Server("s1", "سيرفر رئيسي 1 (سريع)", "1080p HD", isRecommended = true),
        Server("s2", "سيرفر البث الاحتياطي 2", "720p HD"),
        Server("s3", "سيرفر سرعات ضعيفة 3", "480p SD"),
        Server("s4", "سيرفر جودة فائقة 4K", "2160p UHD")
    )

    val movies = listOf(
        Movie(
            id = "m1",
            titleAr = "ولاد رزق 3: القاضية",
            titleEn = "Welad Rizk 3",
            description = "في هذا الجزء، وبعد مرور سنوات على انفصال الأشقاء، يعود شبح من الماضي ليلقي بظلاله على حياتهم، مما يجبرهم على العودة إلى حياة الجريمة والسرقة مرة أخرى لإنقاذ أنفسهم في عملية هي الأكبر والأخطر في تاريخهم.",
            rating = 8.9,
            year = "2024",
            duration = "ساعتان و 10 دقائق",
            category = "arabic",
            genre = "أكشن / جريمة",
            backdropUrl = "https://images.unsplash.com/photo-1536440136628-849c177e76a1?q=80&w=1025&auto=format&fit=crop",
            posterUrl = "https://images.unsplash.com/photo-1485846234645-a62644f84728?q=80&w=1159&auto=format&fit=crop",
            servers = serversList
        ),
        Movie(
            id = "m2",
            titleAr = "كيرة والجن",
            titleEn = "Kira & El Gin",
            description = "يرصد الفيلم حالة الغليان التي كانت يموج بها الشارع المصري بالتزامن مع اندلاع ثورة 1919، وهو الحدث المتوج بمصير كيرة والجن اللذين يشتركان في كفاحهما المسلح ضد الاحتلال البريطاني.",
            rating = 8.6,
            year = "2022",
            duration = "3 ساعات",
            category = "arabic",
            genre = "تاريخي / دراما / أكشن",
            backdropUrl = "https://images.unsplash.com/photo-1440404653325-ab127d49abc1?q=80&w=1170&auto=format&fit=crop",
            posterUrl = "https://images.unsplash.com/photo-1517604931442-7e0c8ed2963c?q=80&w=1170&auto=format&fit=crop",
            servers = serversList
        ),
        Movie(
            id = "m3",
            titleAr = "بيت الروبي",
            titleEn = "Beit El Ruby",
            description = "تدور الأحداث في إطار كوميدي اجتماعي، حول زوجين يعانيان من بعض المشاكل بسبب الإنجاب، فيقرران الذهاب للعيش في إحدى المدن الساحلية، ولكن سرعان ما تتغير الأمور مع زيارة شقيقهما الأصغر.",
            rating = 7.8,
            year = "2023",
            duration = "ساعة و 45 دقيقة",
            category = "arabic",
            genre = "كوميدي / عائلي",
            backdropUrl = "https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?q=80&w=1170&auto=format&fit=crop",
            posterUrl = "https://images.unsplash.com/photo-1478720568477-152d9b164e26?q=80&w=1170&auto=format&fit=crop",
            servers = serversList
        ),
        Movie(
            id = "m4",
            titleAr = "الحريفة",
            titleEn = "The Players",
            description = "تدور أحداث الفيلم في إطار اجتماعي تشويقي حول ماجد لاعب كرة القدم الذي تدفعه الظروف العائلية المادية إلى الانتقال من مدرسته الدولية إلى مدرسة حكومية لينضم للمنافسات الشعبية.",
            rating = 8.1,
            year = "2024",
            duration = "ساعة و 50 دقيقة",
            category = "arabic",
            genre = "دراما / رياضي / كوميدي",
            backdropUrl = "https://images.unsplash.com/photo-1508098682722-e99c43a406b2?q=80&w=1170&auto=format&fit=crop",
            posterUrl = "https://images.unsplash.com/photo-1517524206127-48bbd363f3d7?q=80&w=735&auto=format&fit=crop",
            servers = serversList
        ),

        // Foreign Movies
        Movie(
            id = "m5",
            titleAr = "كثيب: الجزء الثاني",
            titleEn = "Dune: Part Two",
            description = "يستكشف الرحلة الأسطورية لبول أتريدس وهو يتحد مع شاني والفريمن أثناء قيام حرب انتقامية ضد المتآمرين الذين دمروا عائلته. يواجه بول اختيارًا بين حب حياته ومصير الكون.",
            rating = 9.0,
            year = "2024",
            duration = "ساعتان و 46 دقيقة",
            category = "foreign",
            genre = "خيال علمي / مغامرة",
            backdropUrl = "https://images.unsplash.com/photo-1509198397868-475647b2a1e5?q=80&w=1047&auto=format&fit=crop",
            posterUrl = "https://images.unsplash.com/photo-1547483238-f400e65ccd56?q=80&w=1170&auto=format&fit=crop",
            servers = serversList
        ),
        Movie(
            id = "m6",
            titleAr = "أوبنهايمر",
            titleEn = "Oppenheimer",
            description = "يتطرق الفيلم إلى السيرة الذاتية للعالم جيه. روبرت أوبنهايمر ودوره المحوري والقيادي في مشروع مانهاتن لإنشاء القنبلة الذرية التي غيرت العالم تكنولوجياً وسياسياً وعسكرياً.",
            rating = 8.9,
            year = "2023",
            duration = "3 ساعات",
            category = "foreign",
            genre = "سيرة ذاتية / تاريخي / دراما",
            backdropUrl = "https://images.unsplash.com/photo-1451187580459-43490279c0fa?q=80&w=1172&auto=format&fit=crop",
            posterUrl = "https://images.unsplash.com/photo-1440404653325-ab127d49abc1?q=80&w=1170&auto=format&fit=crop",
            servers = serversList
        ),
        Movie(
            id = "m7",
            titleAr = "رجل الملاذ: غضب التنين",
            titleEn = "The Crow: Fire",
            description = "تحقيق يائس يقود بطل القصة لمحاربة المافيا، منخرطًا في سلسلة مواجهات خطيرة لاسترجاع حق عائلته وصديقه الأقرب وملاحقة المجرمين.",
            rating = 7.4,
            year = "2024",
            duration = "ساعتان",
            category = "foreign",
            genre = "أكشن / إثارة / تشويق",
            backdropUrl = "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?q=80&w=1064&auto=format&fit=crop",
            posterUrl = "https://images.unsplash.com/photo-1534447677768-be436bb09401?q=80&w=1194&auto=format&fit=crop",
            servers = serversList
        )
    )

    val matches = listOf(
        Match(
            id = "mt1",
            title = "نهائي دوري أبطال أوروبا",
            league = "دوري أبطال أوروبا",
            teamA = Team("ريال مدريد", "RM", 2),
            teamB = Team("مانشستر سيتي", "MC", 1),
            liveMinute = "72'",
            status = "LIVE",
            time = "9:00 م",
            servers = serversList,
            channel = "beIN Sports HD 1",
            commentator = "عصام الشوالي"
        ),
        Match(
            id = "mt2",
            title = "الدوري الإسباني - الكلاسيكو",
            league = "الدوري الإسباني",
            teamA = Team("برشلونة", "BAR", 0),
            teamB = Team("ريال مدريد", "RM", 0),
            liveMinute = "14'",
            status = "LIVE",
            time = "10:00 م",
            servers = serversList,
            channel = "beIN Sports HD 3",
            commentator = "حفيظ دراجي"
        ),
        Match(
            id = "mt3",
            title = "نهائي كأس مصر الدوري",
            league = "كأس مصر للاندية",
            teamA = Team("الأهلي", "AHL", 0),
            teamB = Team("الزمالك", "ZAM", 0),
            liveMinute = "0",
            status = "UPCOMING",
            time = "8:30 م",
            servers = serversList,
            channel = "أون تايم سبورتس HD 1",
            commentator = "مدحت شلبي"
        ),
        Match(
            id = "mt4",
            title = "الدوري الإنجليزي الممتاز",
            league = "الدوري الإنجليزي",
            teamA = Team("ليفربول", "LIV", 4),
            teamB = Team("أرسنال", "ARS", 2),
            liveMinute = "90+4'",
            status = "FINISHED",
            time = "6:00 م",
            servers = serversList,
            channel = "beIN Sports Premium 1",
            commentator = "خليل البلوشي"
        )
    )

    val channels = listOf(
        TVChannel(
            id = "c1",
            nameAr = "بي إن سبورتس 1",
            nameEn = "beIN Sports HD 1",
            logoText = "beIN 1",
            currentShow = "الاستوديو التحليلي لمباراة الكلاسيكو",
            iconColor = 0xFF5C2D91, // Purple beIN
            category = "رياضة",
            servers = serversList
        ),
        TVChannel(
            id = "c2",
            nameAr = "إم بي سي 1",
            nameEn = "MBC 1",
            logoText = "MBC 1",
            currentShow = "مسلسل العتاولة - الحلقة 18",
            iconColor = 0xFF0D47A1, // Deep Blue
            category = "ترفيه",
            servers = serversList
        ),
        TVChannel(
            id = "c3",
            nameAr = "ناشيونال جيوغرافيك",
            nameEn = "National Geo",
            logoText = "NAT GEO",
            currentShow = "أعماق المحيط الهادي والقرش الأبيض",
            iconColor = 0xFFFFD600, // Gold Yellow
            category = "وثائقي",
            servers = serversList
        ),
        TVChannel(
            id = "c4",
            nameAr = "روتانا سينما",
            nameEn = "Rotana Cinema",
            logoText = "Rotana",
            currentShow = "فيلم تيمور وشفيقة",
            iconColor = 0xFFD81B60, // Pinkish Red
            category = "سينما",
            servers = serversList
        ),
        TVChannel(
            id = "c5",
            nameAr = "سبيستون",
            nameEn = "Spacetoon",
            logoText = "Spacetoon",
            currentShow = "أبطال الديجيتال - موسم 4",
            iconColor = 0xFF26A69A, // Teal Space
            category = "أطفال",
            servers = serversList
        ),
        TVChannel(
            id = "c6",
            nameAr = "الجزيرة الإخبارية",
            nameEn = "Al Jazeera",
            logoText = "Jazeera",
            currentShow = "نشرة الاخبار الحصادية",
            iconColor = 0xFFE65100, // Deep Orange
            category = "أخبار",
            servers = serversList
        )
    )
}
