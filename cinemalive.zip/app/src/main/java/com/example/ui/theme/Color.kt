package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Cinematic Palette
val PrimaryMovieRed = Color(0xFFE50914)  // Netflix Red / Crimson
val PrimaryMatchGreen = Color(0xFF22C55E) // Sports Green-500
val PrimaryTVBlue = Color(0xFF00B0FF)    // TV Vivid Blue

val DarkBackground = Color(0xFF0F0F0F)   // Pitch black from Sleek Interface CSS bg-[#0F0F0F]
val DarkSurface = Color(0xFF161616)      // Sleek surface card
val DarkSurfaceLighter = Color(0xFF222222) // Elevated surface
val TextPrimary = Color(0xFFFFFFFF)      // Pure white readable
val TextSecondary = Color(0xFF94A3B8)    // Sleek slate-400 text color
val TextMuted = Color(0xFF64748B)        // slate-500 text color

val AccentGold = Color(0xFFFFD700)       // Star rating gold
val DarkBorder = Color(0x0DFFFFFF)       // Sleek fine border 5% white (border-white/5)
val HighContrastBorder = Color(0x1AFFFFFF) // 10% white border (border-white/10)

// Gradients
val SleekCardStart = Color(0xFF12141C)
val SleekCardEnd = Color(0xFF1A1D29)

