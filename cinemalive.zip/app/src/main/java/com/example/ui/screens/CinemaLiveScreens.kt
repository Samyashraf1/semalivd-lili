package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.model.Match
import com.example.model.Movie
import com.example.model.TVChannel
import com.example.ui.theme.*
import com.example.viewmodel.CinemaLiveTab
import com.example.viewmodel.CinemaLiveViewModel
import kotlinx.coroutines.delay

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CinemaLiveHeader() {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(DarkBackground)
            .padding(horizontal = 20.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(PrimaryMovieRed),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "CL",
                    fontWeight = FontWeight.Black,
                    fontSize = 12.sp,
                    color = Color.White
                )
            }
            Row {
                Text(
                    text = "Cinema",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = Color.White,
                    letterSpacing = (-0.5).sp
                )
                Text(
                    text = "Live",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = PrimaryMovieRed,
                    letterSpacing = (-0.5).sp
                )
            }
        }
        
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(DarkSurfaceLighter)
                    .border(1.dp, DarkBorder, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Filled.Search,
                    contentDescription = "Search",
                    tint = Color.White,
                    modifier = Modifier.size(18.dp)
                )
            }
            
            AsyncImage(
                model = "https://api.dicebear.com/7.x/avataaars/svg?seed=Felix",
                contentDescription = "Profile",
                modifier = Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .border(2.dp, Color.White.copy(alpha = 0.1f), CircleShape),
                contentScale = ContentScale.Crop
            )
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun MainScreen(
    viewModel: CinemaLiveViewModel,
    modifier: Modifier = Modifier
) {
    val activeTab by viewModel.activeTab.collectAsStateWithLifecycle()
    val isPlayerOpen by viewModel.isPlayerOpen.collectAsStateWithLifecycle()

    // Determine the dynamic active color depending on the navigated section
    val activeHighlightColor = when (activeTab) {
        CinemaLiveTab.MOVIES -> PrimaryMovieRed
        CinemaLiveTab.MATCHES -> PrimaryMatchGreen
        CinemaLiveTab.TV -> PrimaryTVBlue
        CinemaLiveTab.FAVORITES -> AccentGold
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            if (!isPlayerOpen) {
                Column {
                    CinemaLiveHeader()
                    HorizontalDivider(color = DarkBorder, thickness = 1.dp)
                }
            }
        },
        bottomBar = {
            if (!isPlayerOpen) {
                Column {
                    HorizontalDivider(color = DarkBorder, thickness = 1.dp)
                    NavigationBar(
                        containerColor = DarkBackground,
                        contentColor = TextSecondary,
                        tonalElevation = 0.dp,
                        windowInsets = WindowInsets.navigationBars
                    ) {
                        NavigationBarItem(
                            selected = activeTab == CinemaLiveTab.MOVIES,
                            onClick = { viewModel.selectTab(CinemaLiveTab.MOVIES) },
                            icon = { Icon(Icons.Filled.Movie, contentDescription = "أفلام") },
                            label = { Text("أفلام", fontWeight = FontWeight.Bold, fontSize = 11.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = PrimaryMovieRed,
                                selectedTextColor = PrimaryMovieRed,
                                indicatorColor = PrimaryMovieRed.copy(alpha = 0.15f),
                                unselectedIconColor = TextSecondary,
                                unselectedTextColor = TextSecondary
                            ),
                            modifier = Modifier.testTag("nav_movies")
                        )
                        NavigationBarItem(
                            selected = activeTab == CinemaLiveTab.MATCHES,
                            onClick = { viewModel.selectTab(CinemaLiveTab.MATCHES) },
                            icon = { Icon(Icons.Filled.SportsSoccer, contentDescription = "مباريات") },
                            label = { Text("المباريات", fontWeight = FontWeight.Bold, fontSize = 11.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = PrimaryMatchGreen,
                                selectedTextColor = PrimaryMatchGreen,
                                indicatorColor = PrimaryMatchGreen.copy(alpha = 0.15f),
                                unselectedIconColor = TextSecondary,
                                unselectedTextColor = TextSecondary
                            ),
                            modifier = Modifier.testTag("nav_matches")
                        )
                        NavigationBarItem(
                            selected = activeTab == CinemaLiveTab.TV,
                            onClick = { viewModel.selectTab(CinemaLiveTab.TV) },
                            icon = { Icon(Icons.Filled.Tv, contentDescription = "تلفزيون مباشر") },
                            label = { Text("تلفزيون حى", fontWeight = FontWeight.Bold, fontSize = 11.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = PrimaryTVBlue,
                                selectedTextColor = PrimaryTVBlue,
                                indicatorColor = PrimaryTVBlue.copy(alpha = 0.15f),
                                unselectedIconColor = TextSecondary,
                                unselectedTextColor = TextSecondary
                            ),
                            modifier = Modifier.testTag("nav_tv")
                        )
                        NavigationBarItem(
                            selected = activeTab == CinemaLiveTab.FAVORITES,
                            onClick = { viewModel.selectTab(CinemaLiveTab.FAVORITES) },
                            icon = { Icon(Icons.Filled.Favorite, contentDescription = "المفضلة") },
                            label = { Text("مفضلتي", fontWeight = FontWeight.Bold, fontSize = 11.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = AccentGold,
                                selectedTextColor = AccentGold,
                                indicatorColor = AccentGold.copy(alpha = 0.15f),
                                unselectedIconColor = TextSecondary,
                                unselectedTextColor = TextSecondary
                            ),
                            modifier = Modifier.testTag("nav_favorites")
                        )
                    }
                }
            }
        },
        containerColor = DarkBackground
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Screen Switching Navigation with Animation
            AnimatedContent(
                targetState = activeTab,
                transitionSpec = {
                    fadeIn(animationSpec = tween(220)) togetherWith fadeOut(animationSpec = tween(220))
                },
                label = "tab_fade"
            ) { targetTab ->
                when (targetTab) {
                    CinemaLiveTab.MOVIES -> MovieSectionScreen(viewModel)
                    CinemaLiveTab.MATCHES -> MatchSectionScreen(viewModel)
                    CinemaLiveTab.TV -> TVSectionScreen(viewModel)
                    CinemaLiveTab.FAVORITES -> FavoritesSectionScreen(viewModel)
                }
            }

            // Player Fullscreen Overlay View
            AnimatedVisibility(
                visible = isPlayerOpen,
                enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
                exit = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
                modifier = Modifier.fillMaxSize()
            ) {
                PremiumVideoPlayerScreen(viewModel)
            }
        }
    }
}

// -------------------------------------------------------------
// SCREEN 1: NETFLIX-STYLE MOVIE SECTION
// -------------------------------------------------------------
@Composable
fun MovieSectionScreen(viewModel: CinemaLiveViewModel) {
    val movies = viewModel.allMovies
    val arabicMovies = remember(movies) { movies.filter { it.category == "arabic" } }
    val foreignMovies = remember(movies) { movies.filter { it.category == "foreign" } }
    val favoriteIds by viewModel.favoriteMovieIds.collectAsStateWithLifecycle()

    // Hero Movie (Banner top highlight)
    val heroMovie = movies.firstOrNull()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBackground)
    ) {
        // Hero Top Movie Header with large cinematic background
        if (heroMovie != null) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                        .height(240.dp)
                        .clip(RoundedCornerShape(32.dp))
                        .border(1.dp, Color.White.copy(alpha = 0.05f), RoundedCornerShape(32.dp))
                ) {
                    // Movie Backdrop Image with fade bottom brush overlay
                    AsyncImage(
                        model = heroMovie.backdropUrl,
                        contentDescription = heroMovie.titleAr,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )

                    // Netflix Dark Vignette Gradient
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(
                                        Color.Transparent,
                                        Color.Black.copy(alpha = 0.1f),
                                        Color.Black.copy(alpha = 0.85f)
                                    )
                                )
                            )
                    )

                    // Hero Content Box
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .align(Alignment.BottomStart)
                            .padding(20.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        // Badge & Metadata Row
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .background(PrimaryMovieRed, RoundedCornerShape(4.dp))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "إصدار جديد",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.sp
                                )
                            }
                            Text(
                                text = "${heroMovie.genre} • ${heroMovie.year}",
                                color = TextSecondary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Filled.Star,
                                    contentDescription = "Rating",
                                    tint = AccentGold,
                                    modifier = Modifier.size(12.dp)
                                )
                                Spacer(modifier = Modifier.width(3.dp))
                                Text(
                                    text = heroMovie.rating.toString(),
                                    color = TextPrimary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp
                                )
                            }
                        }

                        // Title
                        Text(
                            text = heroMovie.titleAr,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.ExtraBold,
                            color = TextPrimary
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        // Play & Favorite buttons
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            // Watch Button (Pill shaped white button from design "Watch Now")
                            Button(
                                onClick = { viewModel.playMovie(heroMovie) },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color.White,
                                    contentColor = Color.Black
                                ),
                                shape = CircleShape,
                                contentPadding = PaddingValues(horizontal = 20.dp, vertical = 10.dp),
                                modifier = Modifier
                                    .weight(1.5f)
                                    .testTag("play_hero_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.PlayArrow,
                                    contentDescription = null,
                                    tint = Color.Black,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "شاهد الآن",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                            }

                            // Favorite Button Icon (Transparent blurred circular button from design)
                            val isFavorite = favoriteIds.contains(heroMovie.id)
                            IconButton(
                                onClick = { viewModel.toggleFavorite(heroMovie.id) },
                                modifier = Modifier
                                    .background(Color.White.copy(alpha = 0.2f), CircleShape)
                                    .border(1.dp, Color.White.copy(alpha = 0.2f), CircleShape)
                                    .size(38.dp)
                            ) {
                                Icon(
                                    imageVector = if (isFavorite) Icons.Filled.Favorite else Icons.Filled.Add,
                                    contentDescription = "مفضلتي",
                                    tint = if (isFavorite) PrimaryMovieRed else Color.White,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Section: Arabic Cinema
        item {
            Column(modifier = Modifier.padding(top = 16.dp)) {
                Text(
                    text = "الأفلام العربية الأكثر مشاهدة",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                )

                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(arabicMovies) { movie ->
                        MoviePosterCard(movie = movie, onPlay = { viewModel.playMovie(movie) })
                    }
                }
            }
        }

        // Section: Foreign Movies
        item {
            Column(modifier = Modifier.padding(top = 28.dp, bottom = 32.dp)) {
                Text(
                    text = "أقوى الأفلام الأجنبية المترجمة",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                )

                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(foreignMovies) { movie ->
                        MoviePosterCard(movie = movie, onPlay = { viewModel.playMovie(movie) })
                    }
                }
            }
        }
    }
}

@Composable
fun MoviePosterCard(movie: Movie, onPlay: () -> Unit) {
    Card(
        modifier = Modifier
            .width(140.dp)
            .height(245.dp)
            .clickable { onPlay() }
            .border(1.dp, DarkBorder, RoundedCornerShape(16.dp)),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface)
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Poster image
                AsyncImage(
                    model = movie.posterUrl,
                    contentDescription = movie.titleAr,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                )

                // Title and Metadata
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp)
                ) {
                    Text(
                        text = movie.titleAr,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = movie.year, color = TextSecondary, fontSize = 11.sp)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Star, contentDescription = null, tint = AccentGold, modifier = Modifier.size(10.dp))
                            Spacer(modifier = Modifier.width(2.dp))
                            Text(text = movie.rating.toString(), color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        }
                    }
                }
            }

            // High Definition Badge on top-left of Card
            Box(
                modifier = Modifier
                    .padding(6.dp)
                    .background(Color.Black.copy(alpha = 0.75f), RoundedCornerShape(4.dp))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
                    .align(Alignment.TopStart)
            ) {
                Text("FHD", color = AccentGold, fontWeight = FontWeight.Bold, fontSize = 9.sp)
            }
        }
    }
}


// -------------------------------------------------------------
// SCREEN 2: LIVE SCORE & MATCH SPORTSCAMP VIEW
// -------------------------------------------------------------
@Composable
fun MatchSectionScreen(viewModel: CinemaLiveViewModel) {
    val matches = viewModel.allMatches
    val liveMatches = remember(matches) { matches.filter { it.status == "LIVE" } }
    val scheduledMatches = remember(matches) { matches.filter { it.status != "LIVE" } }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBackground),
        contentPadding = PaddingValues(bottom = 32.dp)
    ) {
        // App Sport Header
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(110.dp)
                    .background(
                        Brush.verticalGradient(
                            listOf(
                                PrimaryMatchGreen.copy(alpha = 0.35f),
                                DarkBackground
                            )
                        )
                    )
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxSize(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Filled.SportsSoccer,
                        contentDescription = "كرة قدم",
                        tint = PrimaryMatchGreen,
                        modifier = Modifier.size(32.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "مباريات اليوم المباشرة",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Black,
                            color = TextPrimary
                        )
                        Text(
                            text = "بث مباشر فائق السرعة بجودات متعددة وسيرفرات متميزة",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    }
                }
            }
        }

        // HEADER: Live Now Broadcasts
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Pulsing Red live icon
                LivePulseIndicator()
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "جارية الآن (بث مباشر)",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = PrimaryMatchGreen
                )
            }
        }

        // Live Match Cards
        if (liveMatches.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("لا توجد مباريات جارية حالياً", color = TextSecondary, textAlign = TextAlign.Center)
                }
            }
        } else {
            items(liveMatches) { match ->
                MatchLiveCard(match = match, onWatchClick = { viewModel.playMatch(match) })
            }
        }

        // HEADER: Upcoming and Finished Matches
        item {
            Text(
                text = "باقي مواجهات اليوم والأمس",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = TextPrimary,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 16.dp)
            )
        }

        items(scheduledMatches) { match ->
            MatchSecondaryCard(match = match, onWatchClick = { viewModel.playMatch(match) })
        }
    }
}

@Composable
fun LivePulseIndicator() {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val alpha by infiniteTransition.animateFloat(
        initialValue = 0.2f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_alpha"
    )

    Box(
        modifier = Modifier
            .size(10.dp)
            .clip(CircleShape)
            .background(Color.Red.copy(alpha = alpha))
    )
}

@Composable
fun MatchLiveCard(match: Match, onWatchClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .border(1.dp, Color.White.copy(alpha = 0.05f), RoundedCornerShape(24.dp)),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent)
    ) {
        Column(
            modifier = Modifier
                .background(
                    Brush.linearGradient(
                        colors = listOf(SleekCardStart, SleekCardEnd)
                    )
                )
                .padding(16.dp)
        ) {
            // League and duration row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Live Match Badge
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(7.dp)
                            .clip(CircleShape)
                            .background(Color.Red)
                    )
                    Text(
                        text = "مباشر • ${match.league}",
                        color = Color.Red,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp
                    )
                }

                // Match time minutes
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        Icons.Outlined.AccessTime,
                        contentDescription = null,
                        tint = TextSecondary,
                        modifier = Modifier.size(13.dp)
                    )
                    Text(
                        text = "الدقيقة ${match.liveMinute}'",
                        color = TextSecondary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Club duel score board rows
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                // Team A
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(52.dp)
                            .background(Color.White.copy(alpha = 0.05f), CircleShape)
                            .border(1.dp, Color.White.copy(alpha = 0.1f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(match.teamA.logoUrl, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = match.teamA.nameAr,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        textAlign = TextAlign.Center
                    )
                }

                // Scores (With super elegant sport italic scoreboard styling)
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center,
                    modifier = Modifier.padding(horizontal = 12.dp)
                ) {
                    Text(
                        text = match.teamA.score.toString(),
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Black,
                        color = TextPrimary
                    )
                    Text(
                        text = " - ",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Black,
                        color = TextSecondary,
                        modifier = Modifier.padding(horizontal = 8.dp)
                    )
                    Text(
                        text = match.teamB.score.toString(),
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Black,
                        color = TextPrimary
                    )
                }

                // Team B
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(52.dp)
                            .background(Color.White.copy(alpha = 0.05f), CircleShape)
                            .border(1.dp, Color.White.copy(alpha = 0.1f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(match.teamB.logoUrl, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = match.teamB.nameAr,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        textAlign = TextAlign.Center
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Commentary & Channel details
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(Icons.Filled.Mic, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(13.dp))
                        Text(text = "المعلق: ${match.commentator}", color = TextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                    }
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(Icons.Filled.Tv, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(13.dp))
                        Text(text = "القناة: ${match.channel}", color = TextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                    }
                }

                Button(
                    onClick = onWatchClick,
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryMovieRed),
                    shape = CircleShape,
                    contentPadding = PaddingValues(horizontal = 20.dp, vertical = 10.dp),
                    modifier = Modifier.testTag("match_watch_${match.id}")
                ) {
                    Icon(Icons.Filled.PlayArrow, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("دخول البث", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
        }
    }
}

@Composable
fun MatchSecondaryCard(match: Match, onWatchClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .border(1.dp, DarkBorder, RoundedCornerShape(16.dp)),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1.2f)) {
                Text(match.league, color = PrimaryMatchGreen, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "${match.teamA.nameAr} ضد ${match.teamB.nameAr}",
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary,
                    fontSize = 14.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(Icons.Filled.Mic, contentDescription = null, tint = TextMuted, modifier = Modifier.size(12.dp))
                    Text(match.commentator, color = TextSecondary, fontSize = 11.sp)
                }
            }

            // Score or Status Block
            Box(
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                if (match.status == "FINISHED") {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("انتهت", color = TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Text(
                            text = "${match.teamA.score} - ${match.teamB.score}",
                            color = TextPrimary,
                            fontWeight = FontWeight.Black,
                            fontSize = 16.sp
                        )
                    }
                } else {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("لم تبدأ", color = AccentGold, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Text(
                            text = match.time,
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                }
            }

            Button(
                onClick = onWatchClick,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (match.status == "FINISHED") DarkSurfaceLighter else PrimaryMatchGreen.copy(0.12f)
                ),
                shape = CircleShape,
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                modifier = Modifier.weight(0.8f)
            ) {
                Text(
                    text = if (match.status == "FINISHED") "الملخص" else "تفاصيل",
                    color = if (match.status == "FINISHED") TextSecondary else PrimaryMatchGreen,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 12.sp
                )
            }
        }
    }
}


// -------------------------------------------------------------
// SCREEN 3: LIVE TV EPG & GRID VIEW
// -------------------------------------------------------------
@Composable
fun TVSectionScreen(viewModel: CinemaLiveViewModel) {
    val channels = viewModel.allChannels
    val categories = listOf("الكل", "رياضة", "سينما", "ترفيه", "أطفال", "وثائقي")
    var selectedCategory by remember { mutableStateOf("الكل") }

    val filteredChannels = remember(channels, selectedCategory) {
        if (selectedCategory == "الكل") channels else channels.filter { it.category == selectedCategory }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBackground)
    ) {
        // Live TV Banner
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(100.dp)
                .background(
                    Brush.verticalGradient(
                        listOf(PrimaryTVBlue.copy(0.3f), DarkBackground)
                    )
                )
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxSize(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Filled.Tv, contentDescription = null, tint = PrimaryTVBlue, modifier = Modifier.size(32.dp))
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text("بث تلفزيوني مباشر", fontWeight = FontWeight.Black, color = TextPrimary, fontSize = 16.sp)
                    Text("شاهد قنواتك الترفيهية والرياضية المفضلة كأنك أمام التلفزيون", color = TextSecondary, fontSize = 11.sp)
                }
            }
        }

        // Horizontal Category Chips
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(categories) { category ->
                val isSelected = selectedCategory == category
                FilterChip(
                    selected = isSelected,
                    onClick = { selectedCategory = category },
                    label = { Text(category, fontWeight = FontWeight.Bold) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = PrimaryTVBlue,
                        selectedLabelColor = Color.Black,
                        containerColor = DarkSurface,
                        labelColor = TextSecondary
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Grid of Channels
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            contentPadding = PaddingValues(start = 16.dp, top = 8.dp, end = 16.dp, bottom = 32.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(filteredChannels, key = { it.id }) { channel ->
                ChannelGridCard(channel = channel, onPlay = { viewModel.playChannel(channel) })
            }
        }
    }
}

@Composable
fun ChannelGridCard(channel: TVChannel, onPlay: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(138.dp)
            .clickable { onPlay() }
            .border(1.dp, Color.White.copy(alpha = 0.05f), RoundedCornerShape(16.dp)),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface)
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(14.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    // Logo Circle
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .background(Color(channel.iconColor).copy(alpha = 0.15f), CircleShape)
                            .border(1.dp, Color(channel.iconColor).copy(alpha = 0.40f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = channel.logoText.substring(0, minOf(4, channel.logoText.length)),
                            fontWeight = FontWeight.Black,
                            fontSize = 8.sp,
                            color = Color.White
                        )
                    }

                    // Category Badge
                    Box(
                        modifier = Modifier
                            .background(PrimaryTVBlue.copy(0.12f), RoundedCornerShape(6.dp))
                            .border(1.dp, PrimaryTVBlue.copy(alpha = 0.2f), RoundedCornerShape(6.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = channel.category,
                            color = PrimaryTVBlue,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Name
                Text(
                    text = channel.nameAr,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = TextPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(4.dp))

                // Electronic Program Listing (Currently playing show)
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .background(PrimaryTVBlue, CircleShape)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = channel.currentShow,
                        color = TextSecondary,
                        fontSize = 11.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            // Small active TV tuner signal line at the bottom
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(3.dp)
                    .background(Color(channel.iconColor))
                    .align(Alignment.BottomCenter)
            )
        }
    }
}


// -------------------------------------------------------------
// SCREEN 4: BOOKMARKED FAVORITES SECTION
// -------------------------------------------------------------
@Composable
fun FavoritesSectionScreen(viewModel: CinemaLiveViewModel) {
    val favoriteIds by viewModel.favoriteMovieIds.collectAsStateWithLifecycle()
    val allMovies = viewModel.allMovies
    val favoriteMovies = remember(favoriteIds, allMovies) {
        allMovies.filter { favoriteIds.contains(it.id) }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBackground)
    ) {
        // Favorites header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(100.dp)
                .background(
                    Brush.verticalGradient(
                        listOf(AccentGold.copy(0.2f), DarkBackground)
                    )
                )
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxSize(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Filled.Favorite, contentDescription = null, tint = AccentGold, modifier = Modifier.size(32.dp))
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text("قائمة مفضلتي", fontWeight = FontWeight.Black, color = TextPrimary, fontSize = 16.sp)
                    Text("الأفلام والعروض التي قمت بحفظها للمشاهدة لاحقاً", color = TextSecondary, fontSize = 11.sp)
                }
            }
        }

        if (favoriteMovies.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    Icons.Outlined.FavoriteBorder,
                    contentDescription = null,
                    tint = TextMuted,
                    modifier = Modifier.size(72.dp)
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "قائمتك فارغة",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = TextPrimary
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "ابدأ بتصفح الأفلام وأضف ما ترغب بمشاهدته لاحقاً عبر الضغط على قلب المفضلة.",
                    color = TextSecondary,
                    fontSize = 12.sp,
                    textAlign = TextAlign.Center
                )
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                contentPadding = PaddingValues(start = 16.dp, top = 8.dp, end = 16.dp, bottom = 32.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(favoriteMovies) { movie ->
                    Box(modifier = Modifier.fillMaxWidth()) {
                        MoviePosterCard(movie = movie, onPlay = { viewModel.playMovie(movie) })

                        // Float un-favorite delete button
                        IconButton(
                            onClick = { viewModel.toggleFavorite(movie.id) },
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .padding(4.dp)
                                .background(Color.Black.copy(0.6f), CircleShape)
                                .size(32.dp)
                        ) {
                            Icon(Icons.Filled.Close, contentDescription = "حذف من المفضلة", tint = Color.White, modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
        }
    }
}


// -------------------------------------------------------------
// SCREEN 5: PREMIUM ADVANCED VIDEO PLAYER SHEET & OVERLAY
// -------------------------------------------------------------
@Composable
fun PremiumVideoPlayerScreen(viewModel: CinemaLiveViewModel) {
    val context = LocalContext.current
    val movie by viewModel.selectedMovie.collectAsStateWithLifecycle()
    val match by viewModel.selectedMatch.collectAsStateWithLifecycle()
    val channel by viewModel.selectedChannel.collectAsStateWithLifecycle()

    val currentServer by viewModel.selectedServer.collectAsStateWithLifecycle()
    val isPlaying by viewModel.isPlaying.collectAsStateWithLifecycle()
    val progress by viewModel.playbackProgress.collectAsStateWithLifecycle()
    val volume by viewModel.volume.collectAsStateWithLifecycle()
    val brightness by viewModel.brightness.collectAsStateWithLifecycle()

    val chatMessages by viewModel.chatMessages.collectAsStateWithLifecycle()

    // Title resolution
    val mediaTitle = movie?.titleAr ?: match?.title ?: channel?.nameAr ?: "بث مباشر"
    val mediaSub = movie?.genre ?: match?.league ?: channel?.currentShow ?: "بث خارجي"
    val servers = movie?.servers ?: match?.servers ?: channel?.servers ?: emptyList()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        // 1. Dynamic Video Canvas Player Panel (Custom animated waves represent the stream video)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(240.dp)
                .background(Color.DarkGray)
        ) {
            // Simulated Streaming Video Wave Form Canvas
            StreamSimulatedCanvas(isPlaying = isPlaying)

            // Buffering Spinner Overlay (When paused/loading/switching server)
            if (!isPlaying && progress == 0f) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(0.40f)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator(color = PrimaryMovieRed)
                        Spacer(modifier = Modifier.height(10.dp))
                        Text("جاري تهيئة سيرفر البث المباشر...", color = Color.White, fontSize = 12.sp)
                    }
                }
            }

            // Player Interface Controls overlay
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            listOf(Color.Black.copy(alpha = 0.6f), Color.Transparent, Color.Black.copy(alpha = 0.8f))
                        )
                    )
            ) {
                // Top controls toolbar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp)
                        .align(Alignment.TopCenter),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { viewModel.closePlayer() }) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "رجوع", tint = Color.White)
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = mediaTitle,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = currentServer?.name ?: "تجهيز البث",
                            color = PrimaryTVBlue,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Download or Share icon mock
                    IconButton(onClick = {}) {
                        Icon(Icons.Filled.Share, contentDescription = "مشاركة", tint = Color.White)
                    }
                }

                // Play / Pause core toggle in the center
                IconButton(
                    onClick = { viewModel.togglePlayPause() },
                    modifier = Modifier
                        .size(56.dp)
                        .background(Color.Black.copy(0.55f), CircleShape)
                        .align(Alignment.Center)
                ) {
                    Icon(
                        imageVector = if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                        contentDescription = "تشغيل وقوف",
                        tint = Color.White,
                        modifier = Modifier.size(36.dp)
                    )
                }

                // Volume and Brightness HUD Slider rows at left/right edges
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                        .align(Alignment.BottomCenter),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Time text
                    Text(
                        text = if (movie != null) "${progress.toInt()}%" else "LIVE",
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    // Progress Slider
                    Slider(
                        value = progress,
                        onValueChange = { viewModel.seekTo(it) },
                        valueRange = 0f..100f,
                        colors = SliderDefaults.colors(
                            thumbColor = PrimaryMovieRed,
                            activeTrackColor = PrimaryMovieRed,
                            inactiveTrackColor = Color.Gray
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .height(18.dp)
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    Icon(Icons.Filled.Settings, contentDescription = "جودة البث", tint = Color.White, modifier = Modifier.size(16.dp))
                }
            }
        }

        // 2. Multi-Section Details Tab Below (Scrollable options)
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(DarkBackground)
                .verticalScroll(rememberScrollState())
                .padding(bottom = 32.dp)
        ) {
            // Volume / Brightness sliders row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DarkSurface)
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Filled.VolumeUp, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Slider(
                        value = volume,
                        onValueChange = { viewModel.adjustVolume(it) },
                        valueRange = 0f..100f,
                        colors = SliderDefaults.colors(activeTrackColor = PrimaryTVBlue, thumbColor = PrimaryTVBlue),
                        modifier = Modifier.height(12.dp)
                    )
                }
                Spacer(modifier = Modifier.width(16.dp))
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Filled.Brightness5, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Slider(
                        value = brightness,
                        onValueChange = { viewModel.adjustBrightness(it) },
                        valueRange = 0f..100f,
                        colors = SliderDefaults.colors(activeTrackColor = AccentGold, thumbColor = AccentGold),
                        modifier = Modifier.height(12.dp)
                    )
                }
            }

            // TITLE INFO PANEL
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = mediaTitle,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Text(
                    text = mediaSub,
                    style = MaterialTheme.typography.bodyMedium,
                    color = PrimaryTVBlue,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Detail descriptive text
                movie?.let { m ->
                    Text(
                        text = m.description,
                        color = TextSecondary,
                        fontSize = 13.sp,
                        lineHeight = 18.sp
                    )
                }

                match?.let { mt ->
                    Text(
                        text = "تفاصيل المباراة المباشرة: تشاهدون اللقاء مباشرة بصوت المعلق الرياضي القدير ${mt.commentator} على القناة ${mt.channel}. سرعة استجابة السيرفرات تعتمد على سرعة الاتصال لديك.",
                        color = TextSecondary,
                        fontSize = 13.sp,
                        lineHeight = 18.sp
                    )
                }

                channel?.let { ch ->
                    Text(
                        text = "المشاهدة الحالية للبث التلفزيوني لقناة ${ch.nameAr} الحية والمباشرة على مدار الساعة. تفاعل الآن مع المئات من المشاهدين في الدردشة المباشرة.",
                        color = TextSecondary,
                        fontSize = 13.sp,
                        lineHeight = 18.sp
                    )
                }
            }

            HorizontalDivider(color = DarkBorder, thickness = 1.dp)

            // OPTION 3: WATCHING SERVERS SELECTOR (سيرفرات المشاهدة المتاحة)
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Dns, contentDescription = null, tint = PrimaryMovieRed, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "سيرفرات المشاهدة المتوفرة (اختر السيرفر الأسرع)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Scrollable Column of Server Items
                servers.forEach { server ->
                    val isSelected = currentServer?.id == server.id
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clickable { viewModel.selectServer(server) }
                            .border(
                                width = 1.dp,
                                color = if (isSelected) PrimaryMovieRed else DarkBorder,
                                shape = RoundedCornerShape(12.dp)
                            ),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSelected) Color.White.copy(alpha = 0.03f) else DarkSurface
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Icon(
                                    imageVector = if (isSelected) Icons.Filled.CheckCircle else Icons.Filled.RadioButtonUnchecked,
                                    contentDescription = null,
                                    tint = if (isSelected) PrimaryMovieRed else TextSecondary,
                                    modifier = Modifier.size(20.dp)
                                )
                                Column {
                                    Text(
                                        text = server.name,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isSelected) TextPrimary else TextSecondary,
                                        fontSize = 13.sp
                                    )
                                    Text(
                                        text = "جودة البث: ${server.quality}",
                                        color = TextMuted,
                                        fontSize = 11.sp
                                    )
                                }
                            }

                            // Signal Tag
                            Box(
                                modifier = Modifier
                                    .background(
                                        if (server.isRecommended) PrimaryMatchGreen.copy(alpha = 0.15f) else DarkSurfaceLighter,
                                        RoundedCornerShape(6.dp)
                                    )
                                    .border(
                                        width = 1.dp,
                                        color = if (server.isRecommended) PrimaryMatchGreen.copy(alpha = 0.3f) else Color.Transparent,
                                        shape = RoundedCornerShape(6.dp)
                                    )
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = if (server.isRecommended) "موصى به" else "متاح",
                                    color = if (server.isRecommended) PrimaryMatchGreen else TextSecondary,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }

            HorizontalDivider(color = DarkBorder, thickness = 1.dp)

            // OPTION 4: LIVE SOCIAL CHAT PANEL
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(300.dp)
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        LivePulseIndicator()
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "الدردشة الحية والجمهور المباشر (تفاعلي)",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                    }

                    Box(
                        modifier = Modifier
                            .background(PrimaryTVBlue, RoundedCornerShape(12.dp))
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "${chatMessages.size + 104} متفرج",
                            color = Color.Black,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .background(DarkSurface, RoundedCornerShape(8.dp))
                        .padding(8.dp)
                ) {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        reverseLayout = true // Scroll to bottom naturally
                    ) {
                        items(chatMessages.reversed()) { chat ->
                            ChatMessageRow(chat)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ChatMessageRow(chat: com.example.viewmodel.ChatMessage) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.Top
    ) {
        // Tag badge if VIP
        chat.badge?.let { b ->
            Box(
                modifier = Modifier
                    .padding(end = 4.dp)
                    .background(PrimaryMovieRed, RoundedCornerShape(4.dp))
                    .padding(horizontal = 4.dp, vertical = 2.dp)
            ) {
                Text(b, color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Black)
            }
        }

        Text(
            text = chat.username,
            fontWeight = FontWeight.Bold,
            color = PrimaryTVBlue,
            fontSize = 12.sp,
            modifier = Modifier.padding(end = 6.dp)
        )

        Text(
            text = chat.message,
            color = TextPrimary,
            fontSize = 12.sp,
            modifier = Modifier.weight(1f)
        )

        Text(
            text = chat.time,
            color = TextMuted,
            fontSize = 9.sp,
            modifier = Modifier.padding(start = 6.dp)
        )
    }
}

@Composable
fun StreamSimulatedCanvas(isPlaying: Boolean) {
    var animationProgress by remember { mutableStateOf(0f) }

    LaunchedEffect(isPlaying) {
        if (isPlaying) {
            while (true) {
                animationProgress += 0.05f
                if (animationProgress > 2f * Math.PI.toFloat()) {
                    animationProgress = 0f
                }
                delay(16) // ~60fps
            }
        }
    }

    Canvas(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF07050A))
    ) {
        val width = size.width
        val height = size.height

        // Draw deep space background gradients
        val backgroundGradient = Brush.radialGradient(
            colors = listOf(Color(0xFF2B092C), Color(0xFF08040C)),
            center = Offset(width / 2f, height / 2f),
            radius = width
        )
        drawRect(backgroundGradient)

        // Draw multiple overlapping sine waves to represent running movie streams
        val path1 = Path()
        val path2 = Path()

        path1.moveTo(0f, height / 2f)
        path2.moveTo(0f, height * 0.6f)

        for (x in 0..width.toInt() step 5) {
            val relativeX = x.toFloat() / width
            val sine1 = Math.sin((relativeX * 3.5f * Math.PI + animationProgress).toDouble()).toFloat()
            val sine2 = Math.cos((relativeX * 2.5f * Math.PI - animationProgress).toDouble()).toFloat()

            // scale wave size
            val y1 = height / 2f + sine1 * 35f
            val y2 = height * 0.6f + sine2 * 25f

            path1.lineTo(x.toFloat(), y1)
            path2.lineTo(x.toFloat(), y2)
        }

        drawPath(
            path = path1,
            color = PrimaryMovieRed.copy(alpha = 0.5f),
            style = Stroke(width = 4.dp.toPx())
        )

        drawPath(
            path = path2,
            color = PrimaryTVBlue.copy(alpha = 0.4f),
            style = Stroke(width = 3.dp.toPx())
        )

        // Draw simulated overlay play icons in thin geometry
        drawCircle(
            color = PrimaryMatchGreen.copy(0.12f),
            radius = 180f,
            center = Offset(width / 2f, height / 2f)
        )
    }
}
