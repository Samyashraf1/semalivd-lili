package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val CinemaDarkColorScheme = darkColorScheme(
    primary = PrimaryMovieRed,
    secondary = PrimaryTVBlue,
    tertiary = PrimaryMatchGreen,
    background = DarkBackground,
    surface = DarkSurface,
    onBackground = TextPrimary,
    onSurface = TextPrimary,
    surfaceVariant = DarkSurfaceLighter,
    onSurfaceVariant = TextSecondary,
    outline = DarkBorder
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit,
) {
    // CinemaLive is strictly a cinema-inspired dark layout
    MaterialTheme(
        colorScheme = CinemaDarkColorScheme,
        typography = Typography,
        content = content
    )
}
