package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.model.MockDataProvider
import com.example.model.Movie
import com.example.model.Match
import com.example.model.TVChannel
import com.example.model.Server
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlin.random.Random

enum class CinemaLiveTab {
    MOVIES, MATCHES, TV, FAVORITES
}

data class ChatMessage(
    val id: String,
    val username: String,
    val message: String,
    val time: String,
    val badge: String? = null
)

class CinemaLiveViewModel : ViewModel() {

    private val _activeTab = MutableStateFlow(CinemaLiveTab.MOVIES)
    val activeTab: StateFlow<CinemaLiveTab> = _activeTab.asStateFlow()

    // Loaded Lists
    val allMovies = MockDataProvider.movies
    val allMatches = MockDataProvider.matches
    val allChannels = MockDataProvider.channels

    // Active Playback State
    private val _selectedMovie = MutableStateFlow<Movie?>(null)
    val selectedMovie: StateFlow<Movie?> = _selectedMovie.asStateFlow()

    private val _selectedMatch = MutableStateFlow<Match?>(null)
    val selectedMatch: StateFlow<Match?> = _selectedMatch.asStateFlow()

    private val _selectedChannel = MutableStateFlow<TVChannel?>(null)
    val selectedChannel: StateFlow<TVChannel?> = _selectedChannel.asStateFlow()

    private val _isPlayerOpen = MutableStateFlow(false)
    val isPlayerOpen: StateFlow<Boolean> = _isPlayerOpen.asStateFlow()

    private val _selectedServer = MutableStateFlow<Server?>(null)
    val selectedServer: StateFlow<Server?> = _selectedServer.asStateFlow()

    private val _isPlaying = MutableStateFlow(true)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _playbackProgress = MutableStateFlow(0f)
    val playbackProgress: StateFlow<Float> = _playbackProgress.asStateFlow()

    private val _volume = MutableStateFlow(75f)
    val volume: StateFlow<Float> = _volume.asStateFlow()

    private val _brightness = MutableStateFlow(80f)
    val brightness: StateFlow<Float> = _brightness.asStateFlow()

    // Favorites
    private val _favoriteMovieIds = MutableStateFlow<Set<String>>(setOf("m1", "m5"))
    val favoriteMovieIds: StateFlow<Set<String>> = _favoriteMovieIds.asStateFlow()

    // Live Chat Messages
    private val _chatMessages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val chatMessages: StateFlow<List<ChatMessage>> = _chatMessages.asStateFlow()

    private var chatJob: Job? = null
    private var playbackJob: Job? = null

    init {
        startSimulatedTimeline()
    }

    fun selectTab(tab: CinemaLiveTab) {
        _activeTab.value = tab
    }

    fun playMovie(movie: Movie) {
        _selectedMovie.value = movie
        _selectedMatch.value = null
        _selectedChannel.value = null
        _selectedServer.value = movie.servers.firstOrNull { it.isRecommended } ?: movie.servers.firstOrNull()
        _isPlayerOpen.value = true
        _isPlaying.value = true
        _playbackProgress.value = 0f
        startChatSimulation("movie")
    }

    fun playMatch(match: Match) {
        _selectedMatch.value = match
        _selectedMovie.value = null
        _selectedChannel.value = null
        _selectedServer.value = match.servers.firstOrNull { it.isRecommended } ?: match.servers.firstOrNull()
        _isPlayerOpen.value = true
        _isPlaying.value = true
        _playbackProgress.value = 45f // Start match at half progress
        startChatSimulation("match")
    }

    fun playChannel(channel: TVChannel) {
        _selectedChannel.value = channel
        _selectedMovie.value = null
        _selectedMatch.value = null
        _selectedServer.value = channel.servers.firstOrNull { it.isRecommended } ?: channel.servers.firstOrNull()
        _isPlayerOpen.value = true
        _isPlaying.value = true
        _playbackProgress.value = 0f
        startChatSimulation("tv")
    }

    fun closePlayer() {
        _isPlayerOpen.value = false
        chatJob?.cancel()
    }

    fun selectServer(server: Server) {
        _selectedServer.value = server
        // Add a micro pause/play duration to simulate buffering
        viewModelScope.launch {
            _isPlaying.value = false
            delay(800)
            _isPlaying.value = true
        }
    }

    fun togglePlayPause() {
        _isPlaying.value = !_isPlaying.value
    }

    fun seekTo(progress: Float) {
        _playbackProgress.value = progress
    }

    fun adjustVolume(level: Float) {
        _volume.value = level.coerceIn(0f, 100f)
    }

    fun adjustBrightness(level: Float) {
        _brightness.value = level.coerceIn(0f, 100f)
    }

    fun toggleFavorite(movieId: String) {
        val current = _favoriteMovieIds.value.toMutableSet()
        if (current.contains(movieId)) {
            current.remove(movieId)
        } else {
            current.add(movieId)
        }
        _favoriteMovieIds.value = current
    }

    private fun startSimulatedTimeline() {
        playbackJob?.cancel()
        playbackJob = viewModelScope.launch {
            while (true) {
                delay(1000)
                if (_isPlaying.value) {
                    // Slow incremental progress
                    val next = _playbackProgress.value + 0.2f
                    _playbackProgress.value = if (next > 100f) 0f else next
                }
            }
        }
    }

    private val names = listOf("سامح_99", "أبو_تريكة_الملك", "سارة_مصر", "دحوم_العتيبي", "يحيى_العراقي", "علي_كوجك", "حسام_مصري", "أحمد_سبورت", "CinemaFan", "موسى_غزالي", "رانيا_روتانا")
    
    private val matchComments = listOf(
        "البث ناااااار يا جدعان تسلم إيديكم 🔥",
        "جوووووووووووووووووووووول روعة !!! 😍⚽",
        "سيرفر HD شغال طياااااراااان 🚀⚡",
        "أفضل تطبيق لمشاهدة المباريات بدون أي تقطيع والله العظيم 👍🎖️",
        "يا رباااه على الفرصة الضائعة 😱💔",
        "مين بيعلق على المباراة الحين؟ الشوالي الأسطورة",
        "الحكم ظالم وضربة الجزاء مش صحيحة أبداً 😡",
        "يلااااا يا رجالة لسه في أمل نعوض ⚽🔥",
        "شكل المباراة رايحة للإضافي والا ضربات ترجيح؟",
        "الصوت والصورة جودة فوق الخيال الصراحة 😍"
    )

    private val movieComments = listOf(
        "ولاد رزق 3 أحسن فيلم شفته في حياتي والله 🎬🔥",
        "سيرفر 4k شغال روعة على الشاشة الذكية عندي",
        "مستني كيرة والجن من زمان حوشت عشانه هههه",
        "الصوت محيطي كأني قاعد في السينما بظبط 🎧🍿",
        "القصة روعة وتمثيل طارق لطفي ومكتوبة صح",
        "قسم الأفلام مرتب زي نتفلكس بالضبط سهولة رهيبة ❤️",
        "جاري التحميل لمشاهدتها في المترو 📥🔥",
        "فيلم رهيب يجمع بين الكوميديا والحبكة الدرامية الحزينة"
    )

    private val tvComments = listOf(
        "قناة ناشيونال جيوغرافيك عندي شغالة بأعلى جودة 🗺️🦁",
        "وش كان يمر الحين على روتانا؟ فيلم رهيب جداً 🎭",
        "وين أقدر ألاقي حلقة الأمس؟",
        "كل القنوات مرتبة وسريعة بالفتح ما شاء الله 👌💐",
        "سبيستون قناة ذكريات عمري كبرنا وما زلنا نحبها 🚀⭐",
        "أخبار الجزيرة حية ومباشرة بدون تعليق بالشبكة",
        "أجمل واجهة تلفزيون شفتها في تطبيق أندرويد"
    )

    private fun startChatSimulation(type: String) {
        chatJob?.cancel()
        _chatMessages.value = listOf(
            ChatMessage("1", "البلدوزر_3", "مرحباً بكم في البث المباشر لسينما لايف! 👋🌟", "21:03", "مشرف"),
            ChatMessage("2", "جلال_سينما", "البث يبدأ الحين جودة رووعة", "21:04")
        )

        chatJob = viewModelScope.launch {
            while (true) {
                delay(3000 + Random.nextLong(2000))
                val comments = when (type) {
                    "match" -> matchComments
                    "tv" -> tvComments
                    else -> movieComments
                }
                val randomUser = names[Random.nextInt(names.size)]
                val randomComment = comments[Random.nextInt(comments.size)]
                val timeStr = "21:${String.format("%02d", Random.nextInt(10, 59))}"
                val badge = if (Random.nextFloat() > 0.8f) "VIP ⭐" else null

                val current = _chatMessages.value.toMutableList()
                current.add(ChatMessage(
                    id = Random.nextInt().toString(),
                    username = randomUser,
                    message = randomComment,
                    time = timeStr,
                    badge = badge
                ))
                // Keep last 30 messages
                if (current.size > 30) {
                    current.removeAt(0)
                }
                _chatMessages.value = current
            }
        }
    }
}
